This zip contains the required files for Sfwr Eng 2AA4/Comp Sci 2ME3 assignment 2.

The .class files are located in the bin folder
The JavaDocs for the code is located in the doc folder
The source code (.java) files are located in the src folder
The documentation for Assignment 2 is located in the root folder, titled "Assignment 2 Documentation"
The JAR file is located in the root folder, titled "Run.jar". Note that in order to load a game, you will first need to create a new game, and save it.